<?php
/**
 * Filter hooks.
 *
 * @since   1.0.0
 * @package Rolling
 */
